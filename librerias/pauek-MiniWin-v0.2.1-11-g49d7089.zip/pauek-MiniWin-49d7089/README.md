# MiniWin

MiniWin es un mini-conjunto de funciones para abrir una ventana, 
pintar en ella y detectar la presión de algunas teclas. Lo justo 
para poder implementar juegos sencillos sin necesidad de conocer 
el API de Windows.

MiniWin dispone de [documentación](http://miniwin.readthedocs.io)
cortesía de [Read The Docs](http://readthedocs.org).
