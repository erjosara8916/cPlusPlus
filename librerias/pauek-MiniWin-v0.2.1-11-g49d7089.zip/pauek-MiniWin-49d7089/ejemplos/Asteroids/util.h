#ifndef UTIL_H
#define UTIL_H

void rotar(float& x, float& y, float cx, float cy, float da);
void limites(float& f, float max);
float al_azar(float max);

#endif // UTIL_H
